﻿namespace MilitaryElite.Enums;
public enum Corps
{
    Airforces,
    Marines
}
