﻿using MilitaryElite.Core;
using MilitaryElite.Core.Interfaces;

IEngine engine = new Engine();
engine.Run();